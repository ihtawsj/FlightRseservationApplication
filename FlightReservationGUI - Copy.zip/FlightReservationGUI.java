import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

// Define Passenger, Flight, and Ticket classes if not already defined
class Passenger {
    private String name;
    private int age;

    public Passenger(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }
}

class Flight {
    private String departure;
    private String destination;
    private int seatsAvailable;

    public Flight(String departure, String destination, int seatsAvailable) {
        this.departure = departure;
        this.destination = destination;
        this.seatsAvailable = seatsAvailable;
    }

    public String getDeparture() {
        return departure;
    }

    public String getDestination() {
        return destination;
    }
}

class Ticket {
    private static int nextTicketNumber = 1;
    private int ticketNumber;
    private Passenger passenger;
    private Flight flight;
    private int numberOfSeats;

    public Ticket(Passenger passenger, Flight flight, int numberOfSeats) {
        this.ticketNumber = nextTicketNumber++;
        this.passenger = passenger;
        this.flight = flight;
        this.numberOfSeats = numberOfSeats;
    }

    public int getTicketNumber() {
        return ticketNumber;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public Flight getFlight() {
        return flight;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }
}

public class FlightReservationGUI {
    private List<Ticket> bookedTickets = new ArrayList<>();
    private JTextArea resultArea = new JTextArea(10, 30);
    private JTextField nameField = new JTextField(15);
    private JTextField ageField = new JTextField(3);
    private JTextField departureField = new JTextField(15);
    private JTextField destinationField = new JTextField(15);
    private JTextField seatsField = new JTextField(3);
    private JTextField ticketNumberField = new JTextField(5);

    public FlightReservationGUI() {
        JFrame frame = new JFrame("Flight Reservation System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("Passenger Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Passenger Age:"));
        inputPanel.add(ageField);
        inputPanel.add(new JLabel("Departure:"));
        inputPanel.add(departureField);
        inputPanel.add(new JLabel("Destination:"));
        inputPanel.add(destinationField);
        inputPanel.add(new JLabel("Number of Seats:"));
        inputPanel.add(seatsField);
        inputPanel.add(new JLabel("Ticket Number (for display/cancel):"));
        inputPanel.add(ticketNumberField);

        JPanel buttonPanel = new JPanel();
        JButton bookButton = new JButton("Book Ticket");
        JButton displayButton = new JButton("Display Ticket");
        JButton cancelButton = new JButton("Cancel Ticket");
        JButton exitButton = new JButton("Exit");

        buttonPanel.add(bookButton);
        buttonPanel.add(displayButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(exitButton);

        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(scrollPane, BorderLayout.SOUTH);

        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    int age = Integer.parseInt(ageField.getText());
                    String departure = departureField.getText();
                    String destination = destinationField.getText();
                    int seats = Integer.parseInt(seatsField.getText());
                    bookTicket(name, age, departure, destination, seats);
                } catch (NumberFormatException ex) {
                    resultArea.setText("Please enter valid numbers for age and seats.");
                }
            }
        });

        displayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int ticketNumber = Integer.parseInt(ticketNumberField.getText());
                    displayTicket(ticketNumber);
                } catch (NumberFormatException ex) {
                    resultArea.setText("Please enter a valid ticket number.");
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int ticketNumber = Integer.parseInt(ticketNumberField.getText());
                    cancelTicket(ticketNumber);
                } catch (NumberFormatException ex) {
                    resultArea.setText("Please enter a valid ticket number.");
                }
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        frame.setVisible(true);
    }

    public void bookTicket(String name, int age, String departure, String destination, int seats) {
        Passenger passenger = new Passenger(name, age);
        Flight flight = new Flight(departure, destination, seats);
        Ticket ticket = new Ticket(passenger, flight, seats);
        bookedTickets.add(ticket);
        resultArea.setText("Ticket booked successfully! Ticket number: " + ticket.getTicketNumber());
    }

    public void displayTicket(int ticketNumber) {
        for (Ticket ticket : bookedTickets) {
            if (ticket.getTicketNumber() == ticketNumber) {
                resultArea.setText("Ticket Number: " + ticket.getTicketNumber() + "\n" +
                                   "Passenger: " + ticket.getPassenger().getName() + "\n" +
                                   "Departure: " + ticket.getFlight().getDeparture() + "\n" +
                                   "Destination: " + ticket.getFlight().getDestination() + "\n" +
                                   "Number of seats: " + ticket.getNumberOfSeats());
                return;
            }
        }
        resultArea.setText("Ticket with ticket number " + ticketNumber + " not found.");
    }

    public void cancelTicket(int ticketNumber) {
        Iterator<Ticket> iterator = bookedTickets.iterator();
        while (iterator.hasNext()) {
            Ticket ticket = iterator.next();
            if (ticket.getTicketNumber() == ticketNumber) {
                iterator.remove();
                resultArea.setText("Ticket number " + ticketNumber + " cancelled successfully.");
                return;
            }
        }
        resultArea.setText("Ticket with ticket number " + ticketNumber + " not found.");
    }

    public static void main(String[] args) {
        new FlightReservationGUI();
    }
}
